<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>All Rights Reserved By : BuddyPets &copy;  2020 to <?php echo date("Y");?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->